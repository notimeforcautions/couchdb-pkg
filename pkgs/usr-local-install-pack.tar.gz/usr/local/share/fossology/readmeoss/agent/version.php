<?php
/*
 SPDX-FileCopyrightText: © Fossology contributors

 SPDX-License-Identifier: GPL-2.0-only
*/

define("README_AGENT_NAME", "readmeoss");
define("AGENT_VERSION", "");
define("AGENT_REV", "");
