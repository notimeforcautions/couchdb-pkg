<?php
/*
 SPDX-FileCopyrightText: © Fossology contributors

 SPDX-License-Identifier: GPL-2.0-only
*/
define("AGENT_VERSION", "");
define("AGENT_REV", "");
