/*
 SPDX-FileCopyrightText: © 2014 Siemens AG
 Author: J.Najjar

 SPDX-License-Identifier: GPL-2.0-only
*/

$(document).ready(function () {
  tableCopyright = createTablestatement();
  tableScancode = createTablescancode_statement();
  tableEmail = createTableemail();
      tableUrl = createTableurl();
      tableScanEmail = createTablescancode_email();
      tableScanUrl = createTablescancode_url();
});

