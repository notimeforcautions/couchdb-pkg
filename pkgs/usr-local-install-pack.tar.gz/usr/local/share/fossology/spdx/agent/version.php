<?php
/*
 SPDX-FileCopyrightText: © 2015 Siemens AG

 SPDX-License-Identifier: FSFAP
 */
defined("AGENT_VERSION") or define("AGENT_VERSION", "");
defined("AGENT_REV") or define("AGENT_REV", "");
