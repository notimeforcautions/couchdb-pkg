<?php
/*
 SPDX-FileCopyrightText: © Fossology contributors

 SPDX-License-Identifier: GPL-2.0-only
*/

define("REUSER_AGENT_NAME", "reuser");
defined("AGENT_VERSION") or define("AGENT_VERSION", "");
defined("AGENT_REV") or define("AGENT_REV", "");
