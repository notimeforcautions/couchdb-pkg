<?php
# SPDX-FileCopyrightText: © Fossology contributors

# SPDX-License-Identifier: GPL-2.0-only

define("AGENT_DECIDER_JOB_NAME", "deciderjob");
define("AGENT_DECIDER_JOB_VERSION", "");
define("AGENT_DECIDER_JOB_REV", "");
