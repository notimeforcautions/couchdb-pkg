/*
 * Copyright Siemens AG, 2019. Part of the SW360 Portal Project.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.eclipse.sw360.rest.authserver.client.rest;

import com.google.common.collect.Lists;

import org.eclipse.sw360.rest.authserver.IntegrationTestBase;

import org.junit.Ignore;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.web.client.RestClientException;

import java.net.URI;
import java.net.URISyntaxException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

public class OAuthClientControllerTest extends IntegrationTestBase {

    @Autowired
    private TestRestTemplate template;

    @Test
    public void testGetAll_basicAuth_unknownUser_fail() throws RestClientException, URISyntaxException {
        // given:
        when(clientRepo.getAll()).thenReturn(null);

        // when:
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Lists.newArrayList(MediaType.APPLICATION_JSON));

        responseEntity = template.withBasicAuth("my-unknown-user", "12345").exchange(
                new RequestEntity<String>(headers, HttpMethod.GET, new URI("/client-management")), String.class);

        // then:
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.UNAUTHORIZED));
    }

    @Test
    public void testGetAll_basicAuth_admin_success() throws RestClientException, URISyntaxException {
        // given:
        when(clientRepo.getAll()).thenReturn(null);

        // when:
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Lists.newArrayList(MediaType.APPLICATION_JSON));

        responseEntity = template.withBasicAuth(adminTestUser.email, "12345")
                .exchange(new RequestEntity<String>(headers, HttpMethod.GET, new URI("/client-management")),
                        String.class);

        // then:
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
    }

    @Test
    public void testGetAll_basicAuth_normal_fail() throws RestClientException, URISyntaxException {
        // given:
        when(clientRepo.getAll()).thenReturn(null);

        // when:
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Lists.newArrayList(MediaType.APPLICATION_JSON));

        responseEntity = template.withBasicAuth(normalTestUser.email, "12345")
                .exchange(new RequestEntity<String>(headers, HttpMethod.GET, new URI("/client-management")),
                        String.class);

        // then:
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.FORBIDDEN));
    }

    @Test
    public void testGetAll_headerAuth_unknownUser_fail() throws RestClientException, URISyntaxException {
        // given:
        when(clientRepo.getAll()).thenReturn(null);

        // when:
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Lists.newArrayList(MediaType.APPLICATION_JSON));
        headers.set("authenticated-email", "my-unknown-user");

        responseEntity = template.exchange(
                new RequestEntity<String>(headers, HttpMethod.GET, new URI("/client-management")), String.class);

        // then:
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.UNAUTHORIZED));
    }

    @Test
    @Ignore
    public void testGetAll_headerAuth_admin_success() throws RestClientException, URISyntaxException {
        // given:
        when(clientRepo.getAll()).thenReturn(null);

        // when:
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Lists.newArrayList(MediaType.APPLICATION_JSON));
        headers.set("authenticated-email", adminTestUser.email);

        responseEntity = template.exchange(
                new RequestEntity<String>(headers, HttpMethod.GET, new URI("/client-management")), String.class);

        // then:
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
    }

    @Test
    @Ignore
    public void testGetAll_headerAuth_normal_fail() throws RestClientException, URISyntaxException {
        // given:
        when(clientRepo.getAll()).thenReturn(null);

        // when:
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Lists.newArrayList(MediaType.APPLICATION_JSON));
        headers.set("authenticated-email", normalTestUser.email);

        responseEntity = template.exchange(
                new RequestEntity<String>(headers, HttpMethod.GET, new URI("/client-management")), String.class);

        // then:
        assertThat(responseEntity.getStatusCode(), is(HttpStatus.FORBIDDEN));
    }
}
