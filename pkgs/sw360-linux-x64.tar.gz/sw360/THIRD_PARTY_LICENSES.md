
# Third-Party Licenses

This project includes third-party licenses due distribution:

| Content      | License Type  | License File |
|--------------|--------------|-------------|
| Eclipse Distribution License     | BSD-3-Clause    | [View License](third_party/licenses/BSD-3-CLAUSE) |
| Documentation   | CC0-1.0           | [View License](third_party/licenses/CC0-1.0) |

Each license file is included in the `third_party/licenses/` directory for compliance.
