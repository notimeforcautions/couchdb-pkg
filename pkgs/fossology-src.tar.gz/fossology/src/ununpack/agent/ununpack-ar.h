/*
 Ununpack-ar.h: Headers for unpacking an ar file

 SPDX-FileCopyrightText: © 2007 Hewlett-Packard Development Company, L.P.

 SPDX-License-Identifier: GPL-2.0-only
*/
#ifndef UNPACK_AR_H
#define UNPACK_AR_H

int     ExtractAR     (char *Source, char *Destination);

#endif
