<?php
/*
 SPDX-FileCopyrightText: © 2010 Hewlett-Packard Development Company, L.P.

 SPDX-License-Identifier: GPL-2.0-only
*/

$TEST_DATA_PATH = dirname(__DIR__, 4)."/build/src/ununpack/agent_tests/testdata";
$TEST_RESULT_PATH =dirname(__DIR__, 4)."/build/src/ununpack/agent_tests/test_result";