/*
 SPDX-FileCopyrightText: © 2014-2015 Siemens AG

 SPDX-License-Identifier: GPL-2.0-only
*/

#ifndef NINKA_AGENT_NINKA_HPP
#define NINKA_AGENT_NINKA_HPP

#include "utils.hpp"

extern "C" {
#include "libfossagent.h"
}

#endif // NINKA_AGENT_NINKA_HPP
