-- SPDX-FileCopyrightText: © Fossology contributors

-- SPDX-License-Identifier: GPL-2.0-only
CREATE USER fosstester WITH INHERIT CREATEDB PASSWORD 'fosstester';
